module.exports = require('../build/addons/MomentLocaleUtils');
