

import React, { Component } from 'react'
import capturePaymentDetails from "./capturePaymentDetails";

export default class index extends Component {
	render() {
		return (
			<div>
                <h1>hello MyTry</h1>
	 <capturePaymentDetails />
</div>
		)
	}
}
