module.exports = require('../build/DayPickerInput');
