// Deprecated: remove from the next major version
export default from './MomentLocaleUtils';
