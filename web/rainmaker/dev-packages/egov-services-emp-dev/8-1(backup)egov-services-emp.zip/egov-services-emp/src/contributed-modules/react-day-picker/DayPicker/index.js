module.exports = require('../build/DayPicker');
