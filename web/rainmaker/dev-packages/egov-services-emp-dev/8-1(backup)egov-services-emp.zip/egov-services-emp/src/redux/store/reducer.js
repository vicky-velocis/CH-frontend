

import bookings from "../bookings/reducer";


const rootReducer = {

    bookings

};

export default rootReducer;

